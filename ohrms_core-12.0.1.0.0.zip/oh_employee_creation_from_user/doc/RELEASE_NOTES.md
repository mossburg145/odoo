## Module <oh_employee_creation_from_user>

#### 30.03.2018
#### Version 11.0.1.0.0
##### ADD
- Initial commit for Open HRMS Project
