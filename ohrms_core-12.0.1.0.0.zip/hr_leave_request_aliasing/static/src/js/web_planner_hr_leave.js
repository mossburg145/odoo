odoo.define('planner_hr_leave.planner', function (require) {
"use strict";

var planner = require('web.planner.common');

});
