Open HRMS Leave Request Aliasing
--------------------------------
Supporting Addon for Open HRMS, Allows You To Create Leave Request Automatically From Incoming Emails.

Connect with experts
--------------------

If you have any question/queries/additional works on OpenHRMS or this module, You can drop an email directly to Cybrosys.

Technical Notes
---------------

Here you need to send leave request through email with the following rules.
* You must send leave request through your registered email id.
* Mail subject must be start with 'LEAVE REQUEST '
* Mail body must contain date as per given format (%d/%m/%Y)

Contacts
--------
info - info@cybrosys.com
Jesni Banu - jesni@cybrosys.in

Website:
https://www.openhrms.com
https://www.cybrosys.com
